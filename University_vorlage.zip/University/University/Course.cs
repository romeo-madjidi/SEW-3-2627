﻿namespace University
{
    class Course
    {
        public string Title { get; }

        public string Description { get; }

        public float Credits { get; }

        private List<Student> students = new List<Student>();

        public void Register(Student student)
        {
            students.Add(student);
            student.RegisterFor(this);
        }

        public Course(string title, string description, float credits)
        {
            Title = title;
            Description = description;
            Credits = credits;
        }

        public override string ToString()
        {
            return $"Course {Title} - {Credits} Credits, Number of registered students: TODO";
        }
    }
}
